package com;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
/**

 * Servlet implementation class LoginServlet

 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// TODO Auto-generated method stub

		String username = request.getParameter("username");

		String password = request.getParameter("password");

		//printDbDetails();
		System.out.println(username);
		boolean isValid = checkAuthentication(username, password);
		System.out.println(isValid);
if (isValid) {
			request.setAttribute("message", "Login Success");
		} else {
			request.setAttribute("message", "Login Fauilre");;
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher("AuthResult.jsp");
		dispatcher.forward(request, response);
	}
	private void printDbDetails() {
		DBCursor curs;
		DBConnection dbCon = new DBConnection();
		MongoClient mc = dbCon.getMongoClient();
		DB db = mc.getDB("login");
		DBCollection coll = db.getCollection("user");
		curs = coll.find();
		while(curs.hasNext()) {
			DBObject obj = curs.next();
			System.out.println("User name is : "+obj.get("username"));
           System.out.println("Password is : "+obj.get("password"));
}
	}

	private boolean checkAuthentication(String username, String password) {
		boolean validLogin = false;
		DBCursor curs;
		DBConnection dbCon = new DBConnection();
		MongoClient mc = dbCon.getMongoClient();
		DB db = mc.getDB("login");
		DBCollection coll = db.getCollection("userinfo");
		curs = coll.find();
		while(curs.hasNext()) {
			DBObject obj = curs.next();
			System.out.println(obj.get(username));
			if (obj.get("username").equals(username)) {
			System.out.println("User found");
				
				if (obj.get("password").equals(password)) {
					System.out.println("password matches");
					validLogin = true;
				}
			}
		}
		System.out.println("authenticating");
		return validLogin;
	}
}


