package servlets;

import java.util.Map;
import java.util.Set;

import org.bson.BSONObject;

import com.mongodb.DBObject;

public class Register implements DBObject {
			private String firstname;
		private String lastname;
		private String password;
		private String confirmpassword;
		private String username;
		private String contactnumber;
		private String emailid;
		
		public String getfirstname() {
			return firstname;
		}
		public void setfirstname(String firstname) {
			this.firstname = firstname;
		}
		public String getlastname() {
			return lastname;
		}
		public void setlastname(String lastname) {
			this.lastname = lastname;
		}
		public String getpassword() {
			return password;
		}
		public void setpassword(String password) {
			this.password = password;
		}
		public String getconfirmpassword() {
			return confirmpassword;
		}
		public void setconfirmpassword(String confirmpassword) {
			this.confirmpassword = confirmpassword;
		}
		public String getusername() {
			return username;
		}
		public void setusername(String username) {
			this.username = username;
		}
		public String getcontactnumber() {
			return contactnumber;
		}
		public void setcontactnumber(String contactnumber) {
			this.contactnumber = contactnumber;
		}
		
			public String getemailid() {
				return emailid;
			}
			public void setemailid(String emailid) {
				this.emailid = emailid;
			}
			@Override
			public boolean containsField(String arg0) {
				// TODO Auto-generated method stub
				return false;
			}
			@Override
			public boolean containsKey(String arg0) {
				// TODO Auto-generated method stub
				return false;
			}
			@Override
			public Object get(String arg0) {
				// TODO Auto-generated method stub
				return null;
			}
			@Override
			public Set<String> keySet() {
				// TODO Auto-generated method stub
				return null;
			}
			@Override
			public Object put(String arg0, Object arg1) {
				// TODO Auto-generated method stub
				return null;
			}
			@Override
			public void putAll(BSONObject arg0) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void putAll(Map arg0) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public Object removeField(String arg0) {
				// TODO Auto-generated method stub
				return null;
			}
			@Override
			public Map toMap() {
				// TODO Auto-generated method stub
				return null;
			}
			@Override
			public boolean isPartialObject() {
				// TODO Auto-generated method stub
				return false;
			}
			@Override
			public void markAsPartialObject() {
				// TODO Auto-generated method stub
				
			}
		}
		
		

	


