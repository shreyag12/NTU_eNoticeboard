

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DBConnection;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;

import servlets.ForgotPassword;
import servlets.Register;

/**
 * Servlet implementation class ResetServlet
 */
@WebServlet("/ResetServlet")
public class ResetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResetServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		  PrintWriter out = response.getWriter();

		  Register pb = new Register();
		  String username=request.getParameter("username");    
		  pb.setfirstname(username);
		  String pwd=request.getParameter("OldPassword");   pb.setpassword(pwd);
		  String confirmpwd=request.getParameter("newpassword"); pb.setconfirmpassword(confirmpwd);

		   HttpSession session = request.getSession(false); 

		   try{if (username!=null){
		        session.setAttribute("username",username);}
		    }catch(Exception e){e.printStackTrace();}
		    try{if (pwd!=null){
		        session.setAttribute("Oldpwd",pwd);}
		    }catch(Exception e){e.printStackTrace();}
		    try{if (confirmpwd!=null){
		        session.setAttribute("Newpwd",confirmpwd);}
		    }catch(Exception e){e.printStackTrace();}

		   ForgotPassword dao = new ForgotPassword();
		    

		     try {

		    	 DBConnection dbCon = new DBConnection();
		 		MongoClient mc = dbCon.getMongoClient();
		 		DB db = mc.getDB("login");
		 		DBCollection coll = db.getCollection("userInfo");

		    int status = 0;
			if(status!=0){
		        out.print("<p style=\"color:Green\">Password Changed Successfully!!</p>");  
		        RequestDispatcher rd=request.getRequestDispatcher("/changePassword.jsp");    
		        rd.include(request,response);
		    }
		   else{    
		        out.print("<p style=\"color:red\">**Password doesnot Change.. Try Again! **</p>");    
		        RequestDispatcher rd=request.getRequestDispatcher("/changePassword.jsp");    
		        rd.include(request,response);
		    }

		     }
		   catch(Exception e){
		       e.printStackTrace();
		   }
		} 
}