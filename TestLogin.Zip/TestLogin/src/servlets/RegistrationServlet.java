package servlets;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;


import servlets.Register;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegisterServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unused")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Inside servlet");
		String firstname = request.getParameter("firstName");
		String lastname = request.getParameter("lastname");
		String password = request.getParameter("password");
		String confirmpassword = request.getParameter("confirmpassword");
		String username = request.getParameter("username");
		String contactnumber = request.getParameter("contactnumber");
		String emailid = request.getParameter("emailid");
		System.out.println("first name : "+firstname);
		insertToMongo(firstname,lastname,password,confirmpassword,username,contactnumber,emailid);
		
		request.getRequestDispatcher("index.jsp").forward(request, response);
		
		
		
		
		
	
			MongoClient mongo = (MongoClient) request.getServletContext().getAttribute("MONGO_CLIENT");
			RegistrationDAO registerDAO = new RegistrationDAO(mongo);
			
			
			List<Register> Register = registerDAO.readAllRegister();
		

		}
	

	private void insertToMongo(String firstname, String lastname, String password, String username,String confirmpassword,
			String contactnumber,String emailid) {
		// TODO Auto-generated method stub
		MongoClient mongo = new MongoClient("localhost", 27017);
        DB db = mongo.getDB("login");
        DBCollection collection = db.getCollection("userinfo");
        BasicDBObject document = new BasicDBObject();
        document.put("firstname", firstname);
        document.put("lastname", lastname);
        document.put("password", password);
        document.put("confirmpassword", confirmpassword);
        document.put("username", username);
        document.put("contactnumber", contactnumber);
        document.put("emailid", emailid);
        
        collection.insert(document);
        
	}
	}



