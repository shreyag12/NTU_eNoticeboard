package servlets;
import java.util.ArrayList;
import java.util.List;

import org.bson.types.ObjectId;

import com.DBConnection;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

import servlets.Register;
import servlets.RegistrationDAO;


public class RegistrationDAO {
private DBCollection col;
	
	@SuppressWarnings("deprecation")
	public RegistrationDAO(MongoClient mongo) {

       if(mongo==null){
        	mongo = DBConnection.getMongoClient();
        }

		this.col = mongo.getDB("login").getCollection("userinfo");
	}

	public Register createRegister(Register register) {
		DBObject doc = RegistrationDAO.toDBObject(register);
		this.col.insert(doc);
		ObjectId firstname = (ObjectId) doc.get("_firstname");
		register.setfirstname(firstname.toString());
		ObjectId lastname = (ObjectId) doc.get("lastname");
		register.setlastname(lastname.toString());
		ObjectId password = (ObjectId) doc.get("password");
		register.setpassword(password.toString());
		ObjectId confirmpassword = (ObjectId) doc.get("confirmpassword");
		register.setconfirmpassword(confirmpassword.toString());
		ObjectId username = (ObjectId) doc.get("username");
		register.setusername(username.toString());
		ObjectId contactnumber = (ObjectId) doc.get("contactnumber");
		register.setcontactnumber(contactnumber.toString());
		ObjectId emailid = (ObjectId) doc.get("emailid");
		register.setemailid(emailid.toString());
		
		
		return register;
	}

	private static DBObject toDBObject(Register register) {
		// TODO Auto-generated method stub
		return null;
	}

	

	public List<Register> readAllRegister() {
		List<Register> data = new ArrayList<Register>();
		DBCursor cursor = col.find();
		while (cursor.hasNext()) {
			DBObject doc = cursor.next();
			Register register = RegistrationDAO.toRegister(doc);
			data.add(register);
		}
		return data;
	}

	static Register toRegister(DBObject doc) {
		// TODO Auto-generated method stub
		return null;
	}
}
